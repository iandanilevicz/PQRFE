#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

arma::vec fill_v(int a, int b, arma::vec x){
  int n = b - a + 1;
  arma::vec y(n);
  for(int i=0; i<n; i++){
    y(i) = x(i+a-1);
  }
  return(y);
}

arma::vec rho_koenker(arma::vec x, double tau){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(x(i)<0){
      y(i) = x(i)*(tau-1);
    } else {
      y(i) = x(i)*tau;
    }
  }  
  return(y);
}

arma::vec rho_mq(arma::vec x, double tau, double c){
  int n = x.n_elem;
  arma::vec y(n);
  arma::vec a(n);
  arma::vec y1(n);
  arma::vec y2(n);
  arma::vec b1(n);
  arma::vec b2(n);
  a = abs(x);
  for(int i = 0; i < n; ++i){
    if(a(i) > c){
      b1(i) = 1;
      b2(i) = 0;
    } else {
      b1(i) = 0;
      b2(i) = 1;
    }
    if(x(i) < 0){
      y1(i) = 1-tau;
      y2(i) = 1-tau;
    } else {
      y1(i) = tau;
      y2(i) = tau;
    }
    y1(i) = y1(i) * (c*a(i) - 0.5*pow(c,2));
    y2(i) = y2(i) * (0.5*pow(a(i),2));
    y(i) = (b1(i) * y1(i)) + (b2(i) * y2(i));
  }
  return(y);
}

// [[Rcpp::export(psi_mq)]]
arma::vec psi_mq(arma::vec x, double tau, double c){
  int n = x.n_elem;
  arma::vec y(n);
  arma::vec a(n);
  arma::vec y1(n);
  arma::vec y2(n);
  arma::vec b1(n);
  arma::vec b2(n);
  a = abs(x);
  for(int i = 0; i < n; ++i){
    if(a(i) > c){
      b1(i) = 1;
      b2(i) = 0;
    } else {
      b1(i) = 0;
      b2(i) = 1;
    }
    if(x(i) < 0){
      y1(i) = 1-tau;
      y2(i) = 1-tau;
    } else {
      y1(i) = tau;
      y2(i) = tau;
    }
    y1(i) = y1(i) * c * x(i)/a(i);
    y2(i) = y2(i) * x(i);
    y(i) = (b1(i) * y1(i)) + (b2(i) * y2(i));
  }
  return(y);
}

// [[Rcpp::export(d_psi_mq)]]
arma::vec d_psi_mq(arma::vec x, double tau, double c){
  int n = x.n_elem;
  arma::vec y(n);
  arma::vec a(n);
  arma::vec y1(n);
  arma::vec y2(n);
  arma::vec b1(n);
  arma::vec b2(n);
  a = abs(x);
  for(int i = 0; i < n; ++i){
    if(a(i) > c){
      b1(i) = 1;
      b2(i) = 0;
    } else {
      b1(i) = 0;
      b2(i) = 1;
    }
    if(x(i) < 0){
      y1(i) = 1-tau;
      y2(i) = 1-tau;
    } else {
      y1(i) = tau;
      y2(i) = tau;
    }
    y1(i) = y1(i) * 0;
    y2(i) = y2(i) * 1;
    y(i) = (b1(i) * y1(i)) + (b2(i) * y2(i));
  }
  return(y);
}

arma::vec rho_als(arma::vec x, double tau){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(x(i)<0){
      y(i) = pow(x(i),2)*(1-tau);
    } else {
      y(i) = pow(x(i),2)*tau;
    }
  }  
  return(y);
}

// [[Rcpp::export(psi_als)]]
arma::vec psi_als(arma::vec x, double tau){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(x(i)<0){
      y(i) = 2*x(i)*(1-tau);
    } else {
      y(i) = 2*x(i)*tau;
    }
  }  
  return(y);
}

// [[Rcpp::export(d_psi_als)]]
arma::vec d_psi_als(arma::vec x, double tau){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(x(i)<0){
      y(i) = 2*(1-tau);
    } else {
      y(i) = 2*tau;
    }
  }  
  return(y);
}

// [[Rcpp::export(loss_qr)]]
double loss_qr(arma::vec beta, arma::mat x, arma::vec y, double tau, int N, int d){
  double eta = 0;
  arma::vec res(N);
  arma::vec rho(N);
  res = y - (x * beta);
  rho = rho_koenker(res,tau);
  eta = accu(rho);
  return(log(eta));
}

// [[Rcpp::export(loss_qrfe)]]
double loss_qrfe(arma::vec theta,arma::mat x,arma::vec y,arma::mat z,double tau,int n,int d,int mm){
  double eta;
  arma::vec beta(d);
  arma::vec alpha(mm);
  arma::vec res(n);
  arma::vec rho(n);
  beta = fill_v(1,d, theta); 
  alpha = fill_v((d+1),d+mm, theta); 
  res = y -  (z * alpha) -  (x * beta);
  rho = rho_koenker(res,tau);
  eta = accu(rho);
  return(log(eta));
}

// [[Rcpp::export(loss_qrlasso)]]
double loss_qrlasso(arma::vec theta,arma::mat x,arma::vec y,arma::mat z,double tau,int n,int d,int mm, double lambda){
  double eta;
  arma::vec beta(d);
  arma::vec alpha(mm);
  arma::vec res(n);
  arma::vec rho(n);
  beta = fill_v(1,d, theta); 
  alpha = fill_v(d+1,d+mm, theta); 
  res = y -  (z * alpha) -  (x * beta);   
  rho = rho_koenker(res,tau);
  eta = accu(rho)/n + lambda * accu(abs(alpha));
  return(log(eta));
}

// [[Rcpp::export(loss_mqr)]]
double loss_mqr(arma::vec beta, arma::mat x, arma::vec y, double tau, int N, int d, double c){
  double eta = 0;
  arma::vec res(N);
  arma::vec rho(N);
  res = y -  (x * beta);
  rho = rho_mq(res,tau,c);
  eta = accu(rho);
  return(log(eta));
}

// [[Rcpp::export(loss_mqrfe)]]
double loss_mqrfe(arma::vec theta,arma::mat x,arma::vec y,arma::mat z,double tau,int n,int d,int mm, double c){
  double eta;
  arma::vec beta(d);
  arma::vec alpha(mm);
  arma::vec res(n);
  arma::vec rho(n);
  beta = fill_v(1,d, theta); 
  alpha = fill_v((d+1),d+mm, theta); 
  res = y -  (z * alpha) -  (x * beta);
  rho = rho_mq(res,tau,c);
  eta = accu(rho);
  return(log(eta));
}

// [[Rcpp::export(loss_mqrlasso)]]
double loss_mqrlasso(arma::vec theta,arma::mat x,arma::vec y,arma::mat z,double tau,int n,int d,int mm, double c, double lambda){
  double eta;
  arma::vec beta(d);
  arma::vec alpha(mm);
  arma::vec res(n);
  arma::vec rho(n);
  beta = fill_v(1,d, theta); 
  alpha = fill_v(d+1,d+mm, theta); 
  res = y -  (z * alpha) -  (x * beta);   
  rho = rho_mq(res,tau,c);
  eta = accu(rho)/n + lambda * accu(abs(alpha));
  return(log(eta));
}

// [[Rcpp::export(loss_er)]]
double loss_er(arma::vec beta, arma::mat x, arma::vec y, double tau, int N, int d){
  double eta = 0;
  arma::vec res(N);
  arma::vec rho(N);
  res = y -  (x * beta);
  rho = rho_als(res,tau);
  eta = accu(rho);
  return(log(eta));
}

// [[Rcpp::export(loss_erfe)]]
double loss_erfe(arma::vec theta,arma::mat x,arma::vec y,arma::mat z,double tau,int n,int d,int mm){
  double eta;
  arma::vec beta(d);
  arma::vec alpha(mm);
  arma::vec res(n);
  arma::vec rho(n);
  beta = fill_v(1,d, theta); 
  alpha = fill_v((d+1),d+mm, theta); 
  res = y -  (z * alpha) -  (x * beta);
  rho = rho_als(res,tau);
  eta = accu(rho);
  return(log(eta));
}

// [[Rcpp::export(loss_erlasso)]]
double loss_erlasso(arma::vec theta,arma::mat x,arma::vec y,arma::mat z,double tau,int n,int d,int mm, double lambda){
  double eta;
  arma::vec beta(d);
  arma::vec alpha(mm);
  arma::vec res(n);
  arma::vec rho(n);
  beta = fill_v(1,d, theta); 
  alpha = fill_v(d+1,d+mm, theta); 
  res = y -  (z * alpha) -  (x * beta);   
  rho = rho_als(res,tau);
  eta = accu(rho)/n + lambda * accu(abs(alpha));
  return(log(eta));
}

